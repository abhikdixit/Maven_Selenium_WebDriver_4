package pk_Orange_HRM;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OrangeHRM_Sign_In_From_Excel extends OrangeHRM_TestData {

	ChromeDriver driver;

	@Test(dataProvider="LoginData")
	public void Sign_On(String uname,String password)

	{

		driver.findElement(By.linkText("Sign in")).click();
		driver.findElement(By.name("email")).sendKeys(uname);
		driver.findElement(By.name("passwd")).sendKeys(password);
		driver.findElement(By.name("SubmitLogin")).click();
		driver.findElement(By.linkText("Sign out")).click();
	}

	@BeforeTest
	public void LaunchBrowser() {
		 WebDriverManager.chromedriver().setup();
		    driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
	}

	@AfterTest
	public void CloseBrowser() {
		driver.quit();
	}
}
