package pk_Orange_HRM;

import org.testng.annotations.Test;

public class SmokeTest {
  @Test
  public void SmokeTestExecution() {
	  System.out.println("Batch Execution Started");
  }
}
